#Pregunta 6
#Luis Pablo López Iracheta 192301-9


a = float(input("Primer valor: "))
b = float(input("Segundo valor: "))

x = (3 * a) + (b ** 3)

y = ((7 / 8) * a) + (5 / (16 * b))

print(f"El valor de x es {x}")
print(f"El valor de y es {y}")

print("Fin del programa")
