#Pregunta 4
#Luis Pablo López Iracheta 192301-9

primeraVariable = float(input("Valor del primer numero: "))

segundaVariable = float(input("Valor del segundo numero: "))

#Operaciones

suma = primeraVariable + segundaVariable
resta = primeraVariable - segundaVariable
multiplicacion = primeraVariable * segundaVariable
divicionEntera = primeraVariable // segundaVariable
residuoDivicion = primeraVariable % segundaVariable

print(f"La suma: {suma}")
print(f"El producto: {multiplicacion}")
print(f"La resta: {resta}")
print(f"La divicion entera: {divicionEntera}")
print(f"El residuo de la divición entera: {residuoDivicion}")

print("Fin del programa")
